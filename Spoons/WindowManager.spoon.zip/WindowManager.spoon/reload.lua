-- reload config: ctrl+alt+cmd+r
hs.hotkey.bind({ "ctrl", "alt", "cmd" }, "R", function()
	hs.reload()
end)
